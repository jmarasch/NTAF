﻿using System;
using System.Windows.Forms;
using NewTerra;
using NewTerra.DataCore;
using NewTerra.Permissions;
using NewTerra.PlugInFramework;

namespace NewTerra.ObjectClasses {

    [EditorPlugIn( "GUI $ObjectClassName$ Editor", "0.0.0.0", true,
        new Type[] { typeof( $ObjectClassName$ ) } )]
    public partial class $ObjectClassEditorName$ : OCEditorBase {
        ErrorDisplay
            ErrDisp = new ErrorDisplay();

        public $ObjectClassEditorName$() {
            MyObject = ( $ObjectClassName$ )Activator.CreateInstance( typeof( $ObjectClassName$ ) );
        }

        protected override void button_Cancel_Click( object sender, EventArgs e ) {
            base.button_Cancel_Click( sender, e );
        }

        protected override void button_Save_Click( object sender, EventArgs e ) {
            base.button_Save_Click( sender, e );
        }

        protected override void button_Edit_Click( object sender, EventArgs e ) {
            base.button_Edit_Click( sender, e );
        }

        protected override void Leave_field( object sender, EventArgs e ) {
            base.Leave_field( sender, e );

            if ( sender is Control ) {
                try {
                    //todo send data from the exiting field to the MyObject property
                }
                catch ( Exception ex ) { ErrDisp.ShowMsgDialog( ex ); }
            }
        }

        protected override void Enter_field( object sender, EventArgs e ) {
            base.Enter_field( sender, e );
            //todo hanlde the way special objects act when foccus falls on them
        }

        public override EditorExitCode RunEditor( EditorMode mode ) {
            InitializeComponent();
            return base.RunEditor( mode );
        }

        protected override void PopulateComboboxes() {
            //todo populate any special comboboxes with data
        }

        protected override void PopulateFields() {
            base.PopulateFields();
            //todo populate all custom fields with data from the MyObject property
        }

        protected override void editing( bool editing ) {
            base.editing( editing );
            //todo handle the way special objects are viewd durring editing/not editing
        }
    }
}