﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Xml;
using System.Xml.Serialization;
using NewTerra.DataCore;
using NewTerra.DataCore.Properties;
using NewTerra.Events;
using NewTerra.Interfaces;
using NewTerra.PlugInFramework;
using NewTerra.PrintEngine;
using NewTerra.Permissions;
using System.Collections.Generic;

namespace NewTerra.ObjectClasses {

    [TreeNodePlugIn( "$ObjectClassName$ Tree", "0.0.0.0" )]
    public class $ObjectClassTreeName$ : OCTreeNodeBase {
        public override Type CollectionType {
            get {
                return typeof( $ObjectClassName$ );
            }
        }
    }
}